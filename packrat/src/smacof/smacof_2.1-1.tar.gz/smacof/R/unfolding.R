unfolding <- smacofRect
prefscal <- smacofRect